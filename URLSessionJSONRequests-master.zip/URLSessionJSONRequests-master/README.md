# URLSessionJSONRequests
A project that demonstrates how to use URLSession to make a JSON GET and POST request.
